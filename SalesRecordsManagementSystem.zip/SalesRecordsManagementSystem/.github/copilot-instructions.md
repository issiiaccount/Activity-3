# Copilot Instructions

## Project Guidelines
- User prefers removing the custom rounded-corner styling changes and restoring the original square textbox and button appearance when requested.