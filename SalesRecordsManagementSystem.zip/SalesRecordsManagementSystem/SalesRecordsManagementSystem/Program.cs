using SalesRecordsManagementSystem.Data;

namespace SalesRecordsManagementSystem
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        private static async Task Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            try
            {
                await DatabaseInitializer.InitializeAsync();
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    $"The database could not be initialized.\n\n{exception.Message}",
                    "SalesFlow database setup",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            Application.Run(new SignInForm());
        }
    }
}