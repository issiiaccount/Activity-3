﻿using System;
using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using SalesRecordsManagementSystem.Data;
using SalesRecordsManagementSystem.Models;
using SalesRecordsManagementSystem.Security;

namespace SalesRecordsManagementSystem
{
    public partial class RegisterForm : Form
    {
        private bool passwordVisible;
        private bool confirmPasswordVisible;

        private void SetPlaceholder(TextBox textBox, string text)
        {
            textBox.Text = text;
            textBox.ForeColor = Color.FromArgb(117, 132, 145);
        }

        private void ClearPlaceholder(TextBox textBox, string placeholder)
        {
            if (textBox.Text == placeholder)
            {
                textBox.Clear();
                textBox.ForeColor = Color.FromArgb(44, 61, 75);
            }
        }

        private void RestorePlaceholder(TextBox textBox, string placeholder)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = placeholder;
                textBox.ForeColor = Color.FromArgb(117, 132, 145);
            }
        }

        private void usernameTextBox_Enter(object? sender, EventArgs e) => ClearPlaceholder(usernameTextBox, "Enter your username");
        private void usernameTextBox_Leave(object? sender, EventArgs e) => RestorePlaceholder(usernameTextBox, "Enter your username");
        private void emailTextBox_Enter(object? sender, EventArgs e) => ClearPlaceholder(emailTextBox, "Enter your full name");
        private void emailTextBox_Leave(object? sender, EventArgs e) => RestorePlaceholder(emailTextBox, "Enter your full name");
        private void passwordTextBox_Enter(object? sender, EventArgs e) { ClearPlaceholder(passwordTextBox, "Enter your password"); if (passwordTextBox.Text.Length == 0) passwordTextBox.UseSystemPasswordChar = !passwordVisible; }
        private void passwordTextBox_Leave(object? sender, EventArgs e) { RestorePlaceholder(passwordTextBox, "Enter your password"); if (passwordTextBox.Text == "Enter your password") passwordTextBox.UseSystemPasswordChar = false; }
        private void confirmPasswordTextBox_Enter(object? sender, EventArgs e) { ClearPlaceholder(confirmPasswordTextBox, "Confirm your password"); if (confirmPasswordTextBox.Text.Length == 0) confirmPasswordTextBox.UseSystemPasswordChar = !confirmPasswordVisible; }
        private void confirmPasswordTextBox_Leave(object? sender, EventArgs e) { RestorePlaceholder(confirmPasswordTextBox, "Confirm your password"); if (confirmPasswordTextBox.Text == "Confirm your password") confirmPasswordTextBox.UseSystemPasswordChar = false; }

        public RegisterForm()
        {
            InitializeComponent();
            SetPlaceholder(usernameTextBox, "Enter your username");
            SetPlaceholder(emailTextBox, "Enter your full name");
            SetPlaceholder(passwordTextBox, "Enter your password");
            SetPlaceholder(confirmPasswordTextBox, "Confirm your password");
            passwordTextBox.UseSystemPasswordChar = false;
            confirmPasswordTextBox.UseSystemPasswordChar = false;
        }

        private async void createAccountButton_Click(object? sender, EventArgs e)
        {
            string userName = usernameTextBox.Text.Trim();
            string fullName = emailTextBox.Text.Trim();
            string password = passwordTextBox.Text;
            if (userName == "Enter your username") userName = string.Empty;
            if (fullName == "Enter your full name") fullName = string.Empty;
            if (password == "Enter your password") password = string.Empty;
            if (confirmPasswordTextBox.Text == "Confirm your password") confirmPasswordTextBox.Text = string.Empty;

            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(password))
            {
                ShowMessage("Please complete all fields.", MessageBoxIcon.Information);
                return;
            }

            if (userName.Length < 3 || userName.Length > 80)
            {
                ShowMessage("Username must be between 3 and 80 characters.", MessageBoxIcon.Information);
                usernameTextBox.Focus();
                return;
            }

            if (fullName.Length < 2)
            {
                ShowMessage("Please enter your full name.", MessageBoxIcon.Information);
                emailTextBox.Focus();
                return;
            }

            if (password.Length < 8 || password != confirmPasswordTextBox.Text)
            {
                ShowMessage("Passwords must match and be at least 8 characters long.", MessageBoxIcon.Information);
                passwordTextBox.Focus();
                return;
            }

            try
            {
                await using SalesDbContext context = DatabaseConfiguration.CreateContext();

                if (await context.Users.AnyAsync(user => user.UserName == userName))
                {
                    ShowMessage("That username is already registered.", MessageBoxIcon.Warning);
                    return;
                }

                (string hash, string salt) = PasswordHasher.Hash(password);
                context.Users.Add(new AppUser { UserName = userName, FullName = fullName, PasswordHash = hash, PasswordSalt = salt, Role = "Staff" });
                await context.SaveChangesAsync();

                ShowMessage("Your account has been created. You can now sign in.", MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception exception)
            {
                ShowMessage($"The account could not be created.\n\n{exception.Message}", MessageBoxIcon.Error);
            }
        }

        private void showPasswordButton_Click(object? sender, EventArgs e)
        {
            passwordVisible = !passwordVisible;
            passwordTextBox.UseSystemPasswordChar = !passwordVisible;
            showPasswordButton.Text = passwordVisible ? "◉" : "○";
            showPasswordButton.AccessibleName = passwordVisible ? "Hide password" : "Show password";
        }

        private void showConfirmPasswordButton_Click(object? sender, EventArgs e)
        {
            confirmPasswordVisible = !confirmPasswordVisible;
            confirmPasswordTextBox.UseSystemPasswordChar = !confirmPasswordVisible;
            showConfirmPasswordButton.Text = confirmPasswordVisible ? "◉" : "○";
            showConfirmPasswordButton.AccessibleName = confirmPasswordVisible ? "Hide confirmation password" : "Show confirmation password";
        }

        private void signInLink_Click(object? sender, EventArgs e)
        {
            Close();
        }

        private void ShowMessage(string message, MessageBoxIcon icon)
        {
            MessageBox.Show(this, message, "Create account", MessageBoxButtons.OK, icon);
        }

        private void logoTextLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
