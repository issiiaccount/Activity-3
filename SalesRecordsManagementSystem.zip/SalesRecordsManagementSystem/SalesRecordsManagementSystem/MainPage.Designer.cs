﻿namespace SalesRecordsManagementSystem
{
    partial class MainPage
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            welcomeLabel = new Label();
            logoutButton = new Button();
            SuspendLayout();
            // 
            // welcomeLabel
            // 
            welcomeLabel.AutoSize = true;
            welcomeLabel.Font = new Font("Segoe UI", 28F, FontStyle.Bold);
            welcomeLabel.ForeColor = Color.Black;
            welcomeLabel.Location = new Point(64, 42);
            welcomeLabel.Name = "welcomeLabel";
            welcomeLabel.Size = new Size(200, 51);
            welcomeLabel.TabIndex = 1;
            welcomeLabel.Text = "Welcome!";
            // 
            // logoutButton
            // 
            logoutButton.BackColor = Color.FromArgb(0, 192, 192);
            logoutButton.FlatAppearance.BorderSize = 0;
            logoutButton.FlatStyle = FlatStyle.Flat;
            logoutButton.Font = new Font("Segoe UI", 14F);
            logoutButton.ForeColor = Color.White;
            logoutButton.Location = new Point(66, 105);
            logoutButton.Name = "logoutButton";
            logoutButton.Size = new Size(106, 42);
            logoutButton.TabIndex = 0;
            logoutButton.Text = "Logout";
            logoutButton.UseVisualStyleBackColor = false;
            logoutButton.Click += logoutButton_Click;
            // 
            // MainPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(900, 520);
            Controls.Add(logoutButton);
            Controls.Add(welcomeLabel);
            Font = new Font("Segoe UI", 9F);
            Name = "MainPage";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard | SalesFlow";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label welcomeLabel;
        private Button logoutButton;
    }
}