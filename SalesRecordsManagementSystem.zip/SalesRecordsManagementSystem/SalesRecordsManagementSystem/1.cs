﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SalesRecordsManagementSystem
{
    public partial class _1 : Form
    {
        public _1()
        {
            InitializeComponent();
        }
    }
}
