using Microsoft.EntityFrameworkCore;
using SalesRecordsManagementSystem.Data;
using SalesRecordsManagementSystem.Models;
using SalesRecordsManagementSystem.Security;

namespace SalesRecordsManagementSystem
{
    public partial class SignInForm : Form
    {
        private bool passwordVisible;
        public SignInForm()
        {
            InitializeComponent();
            emailTextBox.Text = "Enter your username";
            emailTextBox.ForeColor = Color.FromArgb(117, 132, 145);
            passwordTextBox.Text = "Enter your password";
            passwordTextBox.ForeColor = Color.FromArgb(117, 132, 145);
            passwordTextBox.UseSystemPasswordChar = false;
        }

        private void emailTextBox_Enter(object? sender, EventArgs e) { if (emailTextBox.Text == "Enter your username") { emailTextBox.Clear(); emailTextBox.ForeColor = Color.FromArgb(44, 61, 75); } }
        private void emailTextBox_Leave(object? sender, EventArgs e) { if (string.IsNullOrWhiteSpace(emailTextBox.Text)) { emailTextBox.Text = "Enter your username"; emailTextBox.ForeColor = Color.FromArgb(117, 132, 145); } }
        private void passwordTextBox_Enter(object? sender, EventArgs e) { if (passwordTextBox.Text == "Enter your password") { passwordTextBox.Clear(); passwordTextBox.ForeColor = Color.FromArgb(44, 61, 75); passwordVisible = false; passwordTextBox.UseSystemPasswordChar = true; showPasswordButton.Text = "○"; } }
        private void passwordTextBox_Leave(object? sender, EventArgs e) { if (string.IsNullOrWhiteSpace(passwordTextBox.Text)) { passwordTextBox.UseSystemPasswordChar = false; passwordTextBox.Text = "Enter your password"; passwordTextBox.ForeColor = Color.FromArgb(117, 132, 145); } }
        private void showPasswordButton_Click(object? sender, EventArgs e) { if (passwordTextBox.Text == "Enter your password") { passwordTextBox.Focus(); return; } passwordVisible = !passwordVisible; passwordTextBox.UseSystemPasswordChar = !passwordVisible; showPasswordButton.Text = passwordVisible ? "◉" : "○"; }

        private async void signInButton_Click(object? sender, EventArgs e)
        {
            string login = emailTextBox.Text.Trim();
            string password = passwordTextBox.Text;
            if (string.IsNullOrWhiteSpace(login) || login.Equals("enter your username", StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(password) || password == "Enter your password") { MessageBox.Show(this, "Please enter your username and password to continue.", "Sign in", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            signInButton.Enabled = false;
            try
            {
                await using SalesDbContext context = DatabaseConfiguration.CreateContext();
                AppUser? user = await context.Users.SingleOrDefaultAsync(candidate => candidate.UserName == login && candidate.IsActive);
                if (user is null || !PasswordHasher.Verify(password, user.PasswordHash, user.PasswordSalt)) { MessageBox.Show(this, "The email or password is incorrect.", "Sign in", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                UserSession.SignIn(user); Hide(); using MainPage mainPage = new(); mainPage.ShowDialog(this); UserSession.SignOut(); Show();
            }
            catch (Exception exception) { MessageBox.Show(this, $"Sign-in could not be completed.\n\n{exception.Message}", "Sign in", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            finally { signInButton.Enabled = true; }
        }

        private void registerLink_Click(object? sender, EventArgs e) { using RegisterForm registerForm = new(); registerForm.ShowDialog(this); }
        private void forgotPasswordLink_LinkClicked(object? sender, LinkLabelLinkClickedEventArgs e) { using ForgotPasswordForm resetForm = new(); resetForm.ShowDialog(this); }
    }
}
