﻿namespace SalesRecordsManagementSystem
{
    partial class SignInForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignInForm));
            leftPanel = new Panel();
            formPanel = new Panel();
            registerLink = new LinkLabel();
            registerPromptLabel = new Label();
            signInButton = new Button();
            forgotPasswordLink = new LinkLabel();
            rememberCheckBox = new CheckBox();
            showPasswordButton = new Button();
            passwordTextBox = new TextBox();
            passwordLabel = new Label();
            emailTextBox = new TextBox();
            emailLabel = new Label();
            subtitleLabel = new Label();
            welcomeLabel = new Label();
            rightPanel = new Panel();
            taglineLabel = new Label();
            brandNameLabel = new Label();
            logoMark = new Panel();
            logoTextLabel = new Label();
            pictureBox1 = new PictureBox();
            leftPanel.SuspendLayout();
            formPanel.SuspendLayout();
            rightPanel.SuspendLayout();
            logoMark.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // leftPanel
            // 
            leftPanel.BackColor = Color.White;
            leftPanel.Controls.Add(formPanel);
            resources.ApplyResources(leftPanel, "leftPanel");
            leftPanel.Name = "leftPanel";
            // 
            // formPanel
            // 
            formPanel.Controls.Add(registerLink);
            formPanel.Controls.Add(registerPromptLabel);
            formPanel.Controls.Add(signInButton);
            formPanel.Controls.Add(forgotPasswordLink);
            formPanel.Controls.Add(rememberCheckBox);
            formPanel.Controls.Add(showPasswordButton);
            formPanel.Controls.Add(passwordTextBox);
            formPanel.Controls.Add(passwordLabel);
            formPanel.Controls.Add(emailTextBox);
            formPanel.Controls.Add(emailLabel);
            formPanel.Controls.Add(subtitleLabel);
            formPanel.Controls.Add(welcomeLabel);
            resources.ApplyResources(formPanel, "formPanel");
            formPanel.Name = "formPanel";
            // 
            // registerLink
            // 
            resources.ApplyResources(registerLink, "registerLink");
            registerLink.LinkColor = Color.FromArgb(22, 151, 139);
            registerLink.Name = "registerLink";
            registerLink.TabStop = true;
            registerLink.Click += registerLink_Click;
            // 
            // registerPromptLabel
            // 
            resources.ApplyResources(registerPromptLabel, "registerPromptLabel");
            registerPromptLabel.ForeColor = Color.FromArgb(117, 132, 145);
            registerPromptLabel.Name = "registerPromptLabel";
            // 
            // signInButton
            // 
            resources.ApplyResources(signInButton, "signInButton");
            signInButton.BackColor = Color.FromArgb(22, 151, 139);
            signInButton.FlatAppearance.BorderSize = 0;
            signInButton.ForeColor = Color.White;
            signInButton.Name = "signInButton";
            signInButton.UseVisualStyleBackColor = false;
            signInButton.Click += signInButton_Click;
            // 
            // forgotPasswordLink
            // 
            resources.ApplyResources(forgotPasswordLink, "forgotPasswordLink");
            forgotPasswordLink.LinkColor = Color.FromArgb(22, 151, 139);
            forgotPasswordLink.Name = "forgotPasswordLink";
            forgotPasswordLink.TabStop = true;
            forgotPasswordLink.LinkClicked += forgotPasswordLink_LinkClicked;
            // 
            // rememberCheckBox
            // 
            resources.ApplyResources(rememberCheckBox, "rememberCheckBox");
            rememberCheckBox.ForeColor = Color.FromArgb(117, 132, 145);
            rememberCheckBox.Name = "rememberCheckBox";
            // 
            // showPasswordButton
            // 
            showPasswordButton.BackColor = Color.White;
            showPasswordButton.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(showPasswordButton, "showPasswordButton");
            showPasswordButton.ForeColor = Color.FromArgb(117, 132, 145);
            showPasswordButton.Name = "showPasswordButton";
            showPasswordButton.UseVisualStyleBackColor = false;
            showPasswordButton.Click += showPasswordButton_Click;
            // 
            // passwordTextBox
            // 
            resources.ApplyResources(passwordTextBox, "passwordTextBox");
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.ForeColor = SystemColors.WindowText;
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.Enter += passwordTextBox_Enter;
            passwordTextBox.Leave += passwordTextBox_Leave;
            // 
            // passwordLabel
            // 
            resources.ApplyResources(passwordLabel, "passwordLabel");
            passwordLabel.ForeColor = Color.FromArgb(44, 61, 75);
            passwordLabel.Name = "passwordLabel";
            // 
            // emailTextBox
            // 
            resources.ApplyResources(emailTextBox, "emailTextBox");
            emailTextBox.BorderStyle = BorderStyle.FixedSingle;
            emailTextBox.ForeColor = SystemColors.WindowText;
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Enter += emailTextBox_Enter;
            emailTextBox.Leave += emailTextBox_Leave;
            // 
            // emailLabel
            // 
            resources.ApplyResources(emailLabel, "emailLabel");
            emailLabel.ForeColor = Color.FromArgb(44, 61, 75);
            emailLabel.Name = "emailLabel";
            // 
            // subtitleLabel
            // 
            resources.ApplyResources(subtitleLabel, "subtitleLabel");
            subtitleLabel.ForeColor = Color.FromArgb(117, 132, 145);
            subtitleLabel.Name = "subtitleLabel";
            // 
            // welcomeLabel
            // 
            resources.ApplyResources(welcomeLabel, "welcomeLabel");
            welcomeLabel.ForeColor = Color.FromArgb(16, 42, 67);
            welcomeLabel.Name = "welcomeLabel";
            // 
            // rightPanel
            // 
            rightPanel.BackColor = Color.FromArgb(16, 42, 67);
            rightPanel.Controls.Add(taglineLabel);
            rightPanel.Controls.Add(brandNameLabel);
            rightPanel.Controls.Add(logoMark);
            rightPanel.ForeColor = SystemColors.ControlText;
            resources.ApplyResources(rightPanel, "rightPanel");
            rightPanel.Name = "rightPanel";
            // 
            // taglineLabel
            // 
            resources.ApplyResources(taglineLabel, "taglineLabel");
            taglineLabel.ForeColor = Color.FromArgb(181, 211, 221);
            taglineLabel.Name = "taglineLabel";
            // 
            // brandNameLabel
            // 
            resources.ApplyResources(brandNameLabel, "brandNameLabel");
            brandNameLabel.ForeColor = Color.White;
            brandNameLabel.Name = "brandNameLabel";
            // 
            // logoMark
            // 
            logoMark.BackColor = Color.FromArgb(32, 184, 164);
            logoMark.Controls.Add(logoTextLabel);
            logoMark.Controls.Add(pictureBox1);
            resources.ApplyResources(logoMark, "logoMark");
            logoMark.Name = "logoMark";
            // 
            // logoTextLabel
            // 
            logoTextLabel.BackColor = Color.Transparent;
            resources.ApplyResources(logoTextLabel, "logoTextLabel");
            logoTextLabel.ForeColor = Color.White;
            logoTextLabel.Name = "logoTextLabel";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(pictureBox1, "pictureBox1");
            pictureBox1.Name = "pictureBox1";
            pictureBox1.TabStop = false;
            // 
            // SignInForm
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(leftPanel);
            Controls.Add(rightPanel);
            Name = "SignInForm";
            leftPanel.ResumeLayout(false);
            formPanel.ResumeLayout(false);
            formPanel.PerformLayout();
            rightPanel.ResumeLayout(false);
            rightPanel.PerformLayout();
            logoMark.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel leftPanel;
        private Panel rightPanel;
        private Panel formPanel;
        private Panel logoMark;
        private Label logoTextLabel;
        private Label brandNameLabel;
        private Label taglineLabel;
        private Label welcomeLabel;
        private Label subtitleLabel;
        private Label emailLabel;
        private TextBox emailTextBox;
        private Label passwordLabel;
        private TextBox passwordTextBox;
        private Button showPasswordButton;
        private CheckBox rememberCheckBox;
        private LinkLabel forgotPasswordLink;
        private Button signInButton;
        private Label registerPromptLabel;
        private LinkLabel registerLink;
        private PictureBox pictureBox1;
    }
}
