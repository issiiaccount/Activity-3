using Microsoft.EntityFrameworkCore;
using SalesRecordsManagementSystem.Data;
using SalesRecordsManagementSystem.Models;
using SalesRecordsManagementSystem.Security;

namespace SalesRecordsManagementSystem;

public partial class ForgotPasswordForm : Form
{
    private bool newPasswordVisible;
    private bool confirmPasswordVisible;

    public ForgotPasswordForm()
    {
        InitializeComponent();
        loginTextBox.Text = "Enter your username";
        loginTextBox.ForeColor = Color.FromArgb(117, 132, 145);
        loginTextBox.Enter += loginTextBox_Enter;
        loginTextBox.Leave += loginTextBox_Leave;
        newPasswordTextBox.Text = "Enter your new password";
        newPasswordTextBox.ForeColor = Color.FromArgb(117, 132, 145);
        newPasswordTextBox.UseSystemPasswordChar = false;
        confirmPasswordTextBox.Text = "Enter your password again";
        confirmPasswordTextBox.ForeColor = Color.FromArgb(117, 132, 145);
        confirmPasswordTextBox.UseSystemPasswordChar = false;
    }

    private void loginTextBox_Enter(object? sender, EventArgs e)
    {
        if (loginTextBox.Text == "Enter your username")
        {
            loginTextBox.Clear();
            loginTextBox.ForeColor = Color.FromArgb(44, 61, 75);
        }
    }

    private void newPasswordTextBox_Enter(object? sender, EventArgs e)
    {
        if (newPasswordTextBox.Text == "Enter your new password")
        {
            newPasswordTextBox.Clear();
            newPasswordTextBox.ForeColor = Color.FromArgb(44, 61, 75);
            newPasswordTextBox.UseSystemPasswordChar = !newPasswordVisible;
        }
    }

    private void newPasswordTextBox_Leave(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(newPasswordTextBox.Text))
        {
            newPasswordTextBox.Text = "Enter your new password";
            newPasswordTextBox.ForeColor = Color.FromArgb(117, 132, 145);
            newPasswordTextBox.UseSystemPasswordChar = false;
        }
    }

    private void confirmPasswordTextBox_Enter(object? sender, EventArgs e)
    {
        if (confirmPasswordTextBox.Text == "Enter your password again")
        {
            confirmPasswordTextBox.Clear();
            confirmPasswordTextBox.ForeColor = Color.FromArgb(44, 61, 75);
            confirmPasswordTextBox.UseSystemPasswordChar = !confirmPasswordVisible;
        }
    }

    private void confirmPasswordTextBox_Leave(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(confirmPasswordTextBox.Text))
        {
            confirmPasswordTextBox.Text = "Enter your password again";
            confirmPasswordTextBox.ForeColor = Color.FromArgb(117, 132, 145);
            confirmPasswordTextBox.UseSystemPasswordChar = false;
        }
    }

    private void showNewPasswordButton_Click(object? sender, EventArgs e)
    {
        if (newPasswordTextBox.Text == "Enter your new password")
        {
            newPasswordTextBox.Focus();
            return;
        }

        newPasswordVisible = !newPasswordVisible;
        newPasswordTextBox.UseSystemPasswordChar = !newPasswordVisible;
        showNewPasswordButton.Text = newPasswordVisible ? "◉" : "○";
    }

    private void showConfirmPasswordButton_Click(object? sender, EventArgs e)
    {
        if (confirmPasswordTextBox.Text == "Enter your password again")
        {
            confirmPasswordTextBox.Focus();
            return;
        }

        confirmPasswordVisible = !confirmPasswordVisible;
        confirmPasswordTextBox.UseSystemPasswordChar = !confirmPasswordVisible;
        showConfirmPasswordButton.Text = confirmPasswordVisible ? "◉" : "○";
    }

    private void loginTextBox_Leave(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(loginTextBox.Text))
        {
            loginTextBox.Text = "Enter your username";
            loginTextBox.ForeColor = Color.FromArgb(117, 132, 145);
        }
    }

    private async void resetPasswordButton_Click(object? sender, EventArgs e)
    {
        string login = loginTextBox.Text.Trim();
        string newPassword = newPasswordTextBox.Text;
        string confirmPassword = confirmPasswordTextBox.Text;

        if (login == "Enter your username") login = string.Empty;
        if (newPassword == "Enter your new password") newPassword = string.Empty;
        if (confirmPassword == "Enter your password again") confirmPassword = string.Empty;

        if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(newPassword) || newPassword != confirmPassword)
        {
                MessageBox.Show(this, "Enter your username and matching passwords.", "Reset password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (newPassword.Length < 8)
        {
            MessageBox.Show(this, "The new password must be at least 8 characters long.", "Reset password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        try
        {
            await using SalesDbContext context = DatabaseConfiguration.CreateContext();
            AppUser? user = await context.Users.SingleOrDefaultAsync(candidate => candidate.UserName == login);
            if (user is null)
            {
                MessageBox.Show(this, "No matching account was found.", "Reset password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            (user.PasswordHash, user.PasswordSalt) = PasswordHasher.Hash(newPassword);
            await context.SaveChangesAsync();
            MessageBox.Show(this, "Your password has been updated. You can now sign in.", "Reset password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception exception)
        {
            MessageBox.Show(this, $"The password could not be updated.\n\n{exception.Message}", "Reset password", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
