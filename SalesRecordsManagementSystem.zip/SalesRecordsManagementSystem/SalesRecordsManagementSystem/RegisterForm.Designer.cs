﻿namespace SalesRecordsManagementSystem
{
    partial class RegisterForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            leftPanel = new Panel();
            taglineLabel = new Label();
            brandNameLabel = new Label();
            logoMark = new Panel();
            logoTextLabel = new Label();
            rightPanel = new Panel();
            formPanel = new Panel();
            createAccountButton = new Button();
            showConfirmPasswordButton = new Button();
            confirmPasswordLabel = new Label();
            showPasswordButton = new Button();
            passwordLabel = new Label();
            emailTextBox = new TextBox();
            emailLabel = new Label();
            usernameTextBox = new TextBox();
            usernameLabel = new Label();
            subtitleLabel = new Label();
            signInLink = new LinkLabel();
            alreadyAccountLabel = new Label();
            titleLabel = new Label();
            passwordTextBox = new TextBox();
            confirmPasswordTextBox = new TextBox();
            leftPanel.SuspendLayout();
            logoMark.SuspendLayout();
            rightPanel.SuspendLayout();
            formPanel.SuspendLayout();
            SuspendLayout();
            // 
            // leftPanel
            // 
            leftPanel.BackColor = Color.FromArgb(16, 42, 67);
            leftPanel.Controls.Add(taglineLabel);
            leftPanel.Controls.Add(brandNameLabel);
            leftPanel.Controls.Add(logoMark);
            leftPanel.Dock = DockStyle.Left;
            leftPanel.Location = new Point(0, 0);
            leftPanel.Name = "leftPanel";
            leftPanel.Size = new Size(390, 583);
            leftPanel.TabIndex = 1;
            // 
            // taglineLabel
            // 
            taglineLabel.Font = new Font("Segoe UI", 11F);
            taglineLabel.ForeColor = Color.FromArgb(181, 211, 221);
            taglineLabel.Location = new Point(42, 314);
            taglineLabel.Name = "taglineLabel";
            taglineLabel.Size = new Size(306, 75);
            taglineLabel.TabIndex = 0;
            taglineLabel.Text = "Create your account and start\nmanaging sales with confidence.";
            taglineLabel.TextAlign = ContentAlignment.TopCenter;
            // 
            // brandNameLabel
            // 
            brandNameLabel.AutoSize = true;
            brandNameLabel.Font = new Font("Segoe UI", 23F, FontStyle.Bold);
            brandNameLabel.ForeColor = Color.White;
            brandNameLabel.Location = new Point(113, 263);
            brandNameLabel.Name = "brandNameLabel";
            brandNameLabel.Size = new Size(161, 42);
            brandNameLabel.TabIndex = 1;
            brandNameLabel.Text = "SalesFlow";
            // 
            // logoMark
            // 
            logoMark.BackColor = Color.FromArgb(32, 184, 164);
            logoMark.Controls.Add(logoTextLabel);
            logoMark.Location = new Point(147, 145);
            logoMark.Name = "logoMark";
            logoMark.Size = new Size(96, 96);
            logoMark.TabIndex = 2;
            // 
            // logoTextLabel
            // 
            logoTextLabel.Dock = DockStyle.Fill;
            logoTextLabel.Font = new Font("Segoe UI", 28F, FontStyle.Bold);
            logoTextLabel.ForeColor = Color.White;
            logoTextLabel.Location = new Point(0, 0);
            logoTextLabel.Name = "logoTextLabel";
            logoTextLabel.Size = new Size(96, 96);
            logoTextLabel.TabIndex = 0;
            logoTextLabel.Text = "SF";
            logoTextLabel.TextAlign = ContentAlignment.MiddleCenter;
            logoTextLabel.Click += logoTextLabel_Click;
            // 
            // rightPanel
            // 
            rightPanel.BackColor = Color.White;
            rightPanel.Controls.Add(formPanel);
            rightPanel.Dock = DockStyle.Fill;
            rightPanel.Location = new Point(390, 0);
            rightPanel.Name = "rightPanel";
            rightPanel.Size = new Size(548, 583);
            rightPanel.TabIndex = 0;
            // 
            // formPanel
            // 
            formPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            formPanel.Controls.Add(createAccountButton);
            formPanel.Controls.Add(showConfirmPasswordButton);
            formPanel.Controls.Add(confirmPasswordLabel);
            formPanel.Controls.Add(showPasswordButton);
            formPanel.Controls.Add(passwordLabel);
            formPanel.Controls.Add(emailTextBox);
            formPanel.Controls.Add(emailLabel);
            formPanel.Controls.Add(usernameTextBox);
            formPanel.Controls.Add(usernameLabel);
            formPanel.Controls.Add(subtitleLabel);
            formPanel.Controls.Add(signInLink);
            formPanel.Controls.Add(alreadyAccountLabel);
            formPanel.Controls.Add(titleLabel);
            formPanel.Controls.Add(passwordTextBox);
            formPanel.Controls.Add(confirmPasswordTextBox);
            formPanel.Location = new Point(20, 34);
            formPanel.Name = "formPanel";
            formPanel.Size = new Size(525, 600);
            formPanel.TabIndex = 0;
            // 
            // createAccountButton
            // 
            createAccountButton.BackColor = Color.FromArgb(22, 151, 139);
            createAccountButton.FlatAppearance.BorderSize = 0;
            createAccountButton.FlatStyle = FlatStyle.Flat;
            createAccountButton.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            createAccountButton.ForeColor = Color.White;
            createAccountButton.Location = new Point(0, 390);
            createAccountButton.Name = "createAccountButton";
            createAccountButton.Size = new Size(430, 44);
            createAccountButton.TabIndex = 0;
            createAccountButton.Text = "CREATE ACCOUNT";
            createAccountButton.UseVisualStyleBackColor = false;
            createAccountButton.Click += createAccountButton_Click;
            // 
            // showConfirmPasswordButton
            // 
            showConfirmPasswordButton.BackColor = Color.White;
            showConfirmPasswordButton.FlatAppearance.BorderSize = 0;
            showConfirmPasswordButton.FlatStyle = FlatStyle.Flat;
            showConfirmPasswordButton.Font = new Font("Segoe UI", 11F);
            showConfirmPasswordButton.ForeColor = Color.FromArgb(117, 132, 145);
            showConfirmPasswordButton.Location = new Point(387, 332);
            showConfirmPasswordButton.Name = "showConfirmPasswordButton";
            showConfirmPasswordButton.Size = new Size(41, 28);
            showConfirmPasswordButton.TabIndex = 2;
            showConfirmPasswordButton.TabStop = false;
            showConfirmPasswordButton.Text = "○";
            showConfirmPasswordButton.UseVisualStyleBackColor = false;
            showConfirmPasswordButton.Click += showConfirmPasswordButton_Click;
            // 
            // confirmPasswordLabel
            // 
            confirmPasswordLabel.AutoSize = true;
            confirmPasswordLabel.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            confirmPasswordLabel.ForeColor = Color.FromArgb(44, 61, 75);
            confirmPasswordLabel.Location = new Point(4, 308);
            confirmPasswordLabel.Name = "confirmPasswordLabel";
            confirmPasswordLabel.Size = new Size(128, 15);
            confirmPasswordLabel.TabIndex = 3;
            confirmPasswordLabel.Text = "CONFIRM PASSWORD";
            // 
            // showPasswordButton
            // 
            showPasswordButton.BackColor = Color.White;
            showPasswordButton.FlatAppearance.BorderSize = 0;
            showPasswordButton.FlatStyle = FlatStyle.Flat;
            showPasswordButton.Font = new Font("Segoe UI", 11F);
            showPasswordButton.ForeColor = Color.FromArgb(117, 132, 145);
            showPasswordButton.Location = new Point(387, 264);
            showPasswordButton.Name = "showPasswordButton";
            showPasswordButton.Size = new Size(41, 28);
            showPasswordButton.TabIndex = 5;
            showPasswordButton.TabStop = false;
            showPasswordButton.Text = "○";
            showPasswordButton.UseVisualStyleBackColor = false;
            showPasswordButton.Click += showPasswordButton_Click;
            // 
            // passwordLabel
            // 
            passwordLabel.AutoSize = true;
            passwordLabel.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            passwordLabel.ForeColor = Color.FromArgb(44, 61, 75);
            passwordLabel.Location = new Point(4, 240);
            passwordLabel.Name = "passwordLabel";
            passwordLabel.Size = new Size(72, 15);
            passwordLabel.TabIndex = 6;
            passwordLabel.Text = "PASSWORD";
            // 
            // emailTextBox
            // 
            emailTextBox.BorderStyle = BorderStyle.FixedSingle;
            emailTextBox.Font = new Font("Segoe UI", 10F);
            emailTextBox.Location = new Point(0, 196);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Size = new Size(430, 25);
            emailTextBox.TabIndex = 7;
            emailTextBox.Enter += emailTextBox_Enter;
            emailTextBox.Leave += emailTextBox_Leave;
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            emailLabel.ForeColor = Color.FromArgb(44, 61, 75);
            emailLabel.Location = new Point(4, 172);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new Size(98, 15);
            emailLabel.TabIndex = 8;
            emailLabel.Text = "FULL NAME";
            // 
            // usernameTextBox
            // 
            usernameTextBox.BorderStyle = BorderStyle.FixedSingle;
            usernameTextBox.Font = new Font("Segoe UI", 10F);
            usernameTextBox.Location = new Point(0, 128);
            usernameTextBox.Name = "usernameTextBox";
            usernameTextBox.Size = new Size(430, 25);
            usernameTextBox.TabIndex = 9;
            usernameTextBox.Enter += usernameTextBox_Enter;
            usernameTextBox.Leave += usernameTextBox_Leave;
            // 
            // usernameLabel
            // 
            usernameLabel.AutoSize = true;
            usernameLabel.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            usernameLabel.ForeColor = Color.FromArgb(44, 61, 75);
            usernameLabel.Location = new Point(4, 104);
            usernameLabel.Name = "usernameLabel";
            usernameLabel.Size = new Size(69, 15);
            usernameLabel.TabIndex = 10;
            usernameLabel.Text = "USERNAME";
            // 
            // subtitleLabel
            // 
            subtitleLabel.AutoSize = true;
            subtitleLabel.Font = new Font("Segoe UI", 10F);
            subtitleLabel.ForeColor = Color.FromArgb(117, 132, 145);
            subtitleLabel.Location = new Point(4, 50);
            subtitleLabel.Name = "subtitleLabel";
            subtitleLabel.Size = new Size(324, 19);
            subtitleLabel.TabIndex = 11;
            subtitleLabel.Text = "Join SalesFlow and manage your business with ease";
            // 
            // signInLink
            // 
            signInLink.AutoSize = true;
            signInLink.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            signInLink.LinkColor = Color.FromArgb(22, 151, 139);
            signInLink.Location = new Point(236, 462);
            signInLink.Name = "signInLink";
            signInLink.Size = new Size(44, 15);
            signInLink.TabIndex = 12;
            signInLink.TabStop = true;
            signInLink.Text = "Sign in";
            signInLink.Click += signInLink_Click;
            // 
            // alreadyAccountLabel
            // 
            alreadyAccountLabel.AutoSize = true;
            alreadyAccountLabel.Font = new Font("Segoe UI", 9F);
            alreadyAccountLabel.ForeColor = Color.FromArgb(117, 132, 145);
            alreadyAccountLabel.Location = new Point(91, 462);
            alreadyAccountLabel.Name = "alreadyAccountLabel";
            alreadyAccountLabel.Size = new Size(142, 15);
            alreadyAccountLabel.TabIndex = 13;
            alreadyAccountLabel.Text = "Already have an account?";
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            titleLabel.ForeColor = Color.FromArgb(16, 42, 67);
            titleLabel.Location = new Point(0, 0);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(257, 46);
            titleLabel.TabIndex = 14;
            titleLabel.Text = "Create account";
            // 
            // passwordTextBox
            // 
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Font = new Font("Segoe UI", 10F);
            passwordTextBox.Location = new Point(0, 264);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.Size = new Size(430, 25);
            passwordTextBox.TabIndex = 4;
            passwordTextBox.UseSystemPasswordChar = true;
            passwordTextBox.Enter += passwordTextBox_Enter;
            passwordTextBox.Leave += passwordTextBox_Leave;
            // 
            // confirmPasswordTextBox
            // 
            confirmPasswordTextBox.BorderStyle = BorderStyle.FixedSingle;
            confirmPasswordTextBox.Font = new Font("Segoe UI", 10F);
            confirmPasswordTextBox.Location = new Point(0, 332);
            confirmPasswordTextBox.Name = "confirmPasswordTextBox";
            confirmPasswordTextBox.Size = new Size(430, 25);
            confirmPasswordTextBox.TabIndex = 1;
            confirmPasswordTextBox.UseSystemPasswordChar = true;
            confirmPasswordTextBox.Enter += confirmPasswordTextBox_Enter;
            confirmPasswordTextBox.Leave += confirmPasswordTextBox_Leave;
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(938, 583);
            Controls.Add(rightPanel);
            Controls.Add(leftPanel);
            Font = new Font("Segoe UI", 9F);
            MinimumSize = new Size(900, 600);
            Name = "RegisterForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Create account | SalesFlow";
            leftPanel.ResumeLayout(false);
            leftPanel.PerformLayout();
            logoMark.ResumeLayout(false);
            rightPanel.ResumeLayout(false);
            formPanel.ResumeLayout(false);
            formPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel leftPanel;
        private Panel rightPanel;
        private Panel formPanel;
        private Panel logoMark;
        private Label logoTextLabel;
        private Label brandNameLabel;
        private Label taglineLabel;
        private Label titleLabel;
        private Label subtitleLabel;
        private Label usernameLabel;
        private TextBox usernameTextBox;
        private Label emailLabel;
        private TextBox emailTextBox;
        private Label passwordLabel;
        private TextBox passwordTextBox;
        private Label confirmPasswordLabel;
        private TextBox confirmPasswordTextBox;
        private Button showPasswordButton;
        private Button showConfirmPasswordButton;
        private Button createAccountButton;
        private Label alreadyAccountLabel;
        private LinkLabel signInLink;
    }
}