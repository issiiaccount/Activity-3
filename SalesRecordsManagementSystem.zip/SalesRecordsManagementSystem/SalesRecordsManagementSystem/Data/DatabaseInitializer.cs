using Microsoft.EntityFrameworkCore;

namespace SalesRecordsManagementSystem.Data;

public static class DatabaseInitializer
{
    public static async Task InitializeAsync()
    {
        await using SalesDbContext context = DatabaseConfiguration.CreateContext();
        await context.Database.EnsureCreatedAsync();
    }
}
