using Microsoft.EntityFrameworkCore;

namespace SalesRecordsManagementSystem.Data;

public static class DatabaseConfiguration
{
    public static string FindDatabasePath()
    {
        string databasePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SalesDB.mdf");
        if (File.Exists(databasePath))
        {
            return databasePath;
        }

        DirectoryInfo? directory = new(AppContext.BaseDirectory);
        for (int level = 0; level < 6 && directory is not null; level++, directory = directory.Parent)
        {
            string candidate = Path.Combine(directory.FullName, "SalesDB.mdf");
            if (File.Exists(candidate))
            {
                return candidate;
            }
        }

        throw new FileNotFoundException($"SalesDB.mdf was not found. Place it in Documents or the project folder.\nSearched from: {AppContext.BaseDirectory}");
    }

    public static DbContextOptions<SalesDbContext> CreateOptions()
    {
        string databasePath = FindDatabasePath();
        string connectionString = $"Server=(localdb)\\MSSQLLocalDB;AttachDbFilename={databasePath};Integrated Security=True;Connect Timeout=30;TrustServerCertificate=True";
        return new DbContextOptionsBuilder<SalesDbContext>().UseSqlServer(connectionString).Options;
    }

    public static SalesDbContext CreateContext() => new(CreateOptions());
}
