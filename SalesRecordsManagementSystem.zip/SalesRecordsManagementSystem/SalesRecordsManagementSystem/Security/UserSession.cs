using SalesRecordsManagementSystem.Models;

namespace SalesRecordsManagementSystem.Security;

public static class UserSession
{
    public static AppUser? CurrentUser { get; private set; }

    public static void SignIn(AppUser user)
    {
        CurrentUser = user;
    }

    public static void SignOut()
    {
        CurrentUser = null;
    }
}
