using System.Security.Cryptography;

namespace SalesRecordsManagementSystem.Security;

public static class PasswordHasher
{
    private const int SaltSize = 32;
    private const int HashSize = 32;
    private const int Iterations = 600_000;

    public static (string Hash, string Salt) Hash(string password)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(password);

        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
            password,
            salt,
            Iterations,
            HashAlgorithmName.SHA512,
            HashSize);

        return (Convert.ToBase64String(hash), Convert.ToBase64String(salt));
    }

    public static bool Verify(string password, string expectedHash, string salt)
    {
        if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(expectedHash) || string.IsNullOrEmpty(salt))
        {
            return false;
        }

        try
        {
            byte[] saltBytes = Convert.FromBase64String(salt);
            byte[] expectedHashBytes = Convert.FromBase64String(expectedHash);
            byte[] actualHash = Rfc2898DeriveBytes.Pbkdf2(
                password,
                saltBytes,
                Iterations,
                HashAlgorithmName.SHA512,
                expectedHashBytes.Length);

            return CryptographicOperations.FixedTimeEquals(actualHash, expectedHashBytes);
        }
        catch (FormatException)
        {
            return false;
        }
    }
}
