﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SalesRecordsManagementSystem.Security;

namespace SalesRecordsManagementSystem
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void logoutButton_Click(object? sender, EventArgs e)
        {
            UserSession.SignOut();
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
