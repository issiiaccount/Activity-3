namespace SalesRecordsManagementSystem;

partial class ForgotPasswordForm
{
    private Label titleLabel = null!;
    private Label loginLabel = null!;
    private TextBox loginTextBox = null!;
    private Label newPasswordLabel = null!;
    private TextBox newPasswordTextBox = null!;
    private Button showNewPasswordButton = null!;
    private Label confirmPasswordLabel = null!;
    private TextBox confirmPasswordTextBox = null!;
    private Button showConfirmPasswordButton = null!;
    private Button resetPasswordButton = null!;

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        titleLabel = new Label();
        loginLabel = new Label();
        loginTextBox = new TextBox();
        newPasswordLabel = new Label();
        newPasswordTextBox = new TextBox();
        showNewPasswordButton = new Button();
        confirmPasswordLabel = new Label();
        confirmPasswordTextBox = new TextBox();
        showConfirmPasswordButton = new Button();
        resetPasswordButton = new Button();
        SuspendLayout();
        titleLabel.AutoSize = true;
        titleLabel.Font = new Font("Segoe UI", 22F, FontStyle.Bold);
        titleLabel.ForeColor = Color.FromArgb(16, 42, 67);
        titleLabel.Location = new Point(42, 28);
        titleLabel.Text = "Reset password";
        loginLabel.AutoSize = true;
        loginLabel.Location = new Point(44, 91);
        loginLabel.Text = "USERNAME";
        loginTextBox.Location = new Point(44, 114);
        loginTextBox.Size = new Size(360, 27);
        loginTextBox.Text = "Enter your username";
        loginTextBox.ForeColor = Color.FromArgb(117, 132, 145);
        newPasswordLabel.AutoSize = true;
        newPasswordLabel.Location = new Point(44, 157);
        newPasswordLabel.Text = "NEW PASSWORD";
        newPasswordTextBox.Location = new Point(44, 180);
        newPasswordTextBox.Size = new Size(320, 27);
        newPasswordTextBox.Text = "Enter your new password";
        newPasswordTextBox.ForeColor = Color.FromArgb(117, 132, 145);
        newPasswordTextBox.Enter += newPasswordTextBox_Enter;
        newPasswordTextBox.Leave += newPasswordTextBox_Leave;
        showNewPasswordButton.BackColor = Color.White;
        showNewPasswordButton.FlatAppearance.BorderSize = 0;
        showNewPasswordButton.FlatStyle = FlatStyle.Flat;
        showNewPasswordButton.ForeColor = Color.FromArgb(117, 132, 145);
        showNewPasswordButton.Location = new Point(364, 178);
        showNewPasswordButton.Size = new Size(40, 30);
        showNewPasswordButton.Text = "○";
        showNewPasswordButton.Click += showNewPasswordButton_Click;
        confirmPasswordLabel.AutoSize = true;
        confirmPasswordLabel.Location = new Point(44, 223);
        confirmPasswordLabel.Text = "CONFIRM PASSWORD";
        confirmPasswordTextBox.Location = new Point(44, 246);
        confirmPasswordTextBox.Size = new Size(320, 27);
        confirmPasswordTextBox.Text = "Enter your password again";
        confirmPasswordTextBox.ForeColor = Color.FromArgb(117, 132, 145);
        confirmPasswordTextBox.Enter += confirmPasswordTextBox_Enter;
        confirmPasswordTextBox.Leave += confirmPasswordTextBox_Leave;
        showConfirmPasswordButton.BackColor = Color.White;
        showConfirmPasswordButton.FlatAppearance.BorderSize = 0;
        showConfirmPasswordButton.FlatStyle = FlatStyle.Flat;
        showConfirmPasswordButton.ForeColor = Color.FromArgb(117, 132, 145);
        showConfirmPasswordButton.Location = new Point(364, 244);
        showConfirmPasswordButton.Size = new Size(40, 30);
        showConfirmPasswordButton.Text = "○";
        showConfirmPasswordButton.Click += showConfirmPasswordButton_Click;
        resetPasswordButton.BackColor = Color.FromArgb(22, 151, 139);
        resetPasswordButton.FlatAppearance.BorderSize = 0;
        resetPasswordButton.FlatStyle = FlatStyle.Flat;
        resetPasswordButton.ForeColor = Color.White;
        resetPasswordButton.Location = new Point(44, 302);
        resetPasswordButton.Size = new Size(360, 42);
        resetPasswordButton.Text = "RESET PASSWORD";
        resetPasswordButton.Click += resetPasswordButton_Click;
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.White;
        ClientSize = new Size(450, 395);
        Controls.Add(resetPasswordButton);
        Controls.Add(showConfirmPasswordButton);
        Controls.Add(confirmPasswordTextBox);
        Controls.Add(confirmPasswordLabel);
        Controls.Add(newPasswordTextBox);
        Controls.Add(showNewPasswordButton);
        Controls.Add(newPasswordLabel);
        Controls.Add(loginTextBox);
        Controls.Add(loginLabel);
        Controls.Add(titleLabel);
        StartPosition = FormStartPosition.CenterParent;
        Text = "Reset password | SalesFlow";
        ResumeLayout(false);
        PerformLayout();
    }
}
